import { loadStripe } from '@stripe/stripe-js';
import { supabase } from './supabase';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY);

async function isTrainingModeActive(): Promise<boolean> {
  const { data } = await supabase
    .from('app_settings')
    .select('value')
    .eq('key', 'training_mode_enabled')
    .maybeSingle();

  return data?.value === true;
}

export async function createCheckoutSession(billingCycle: 'monthly' | 'annual' = 'monthly') {
  if (await isTrainingModeActive()) {
    throw new Error('Training Mode is active. Use the "Activate Pro (Test)" button instead.');
  }

  const monthlyPriceId = import.meta.env.VITE_STRIPE_PRO_PRICE_ID;
  const annualPriceId = import.meta.env.VITE_STRIPE_PRO_ANNUAL_PRICE_ID;

  const priceId = billingCycle === 'annual' ? (annualPriceId || monthlyPriceId) : monthlyPriceId;

  if (!priceId) {
    throw new Error('Stripe Price ID not configured');
  }

  const { data: { session } } = await supabase.auth.getSession();

  if (!session) {
    throw new Error('Not authenticated');
  }

  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const apiUrl = `${supabaseUrl}/functions/v1/create-checkout-session`;

  const response = await fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${session.access_token}`,
      'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      priceId,
      successUrl: `${window.location.origin}/dashboard?subscription=success`,
      cancelUrl: `${window.location.origin}/dashboard?subscription=cancelled`,
    }),
  });

  const text = await response.text();
  let data: Record<string, unknown>;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error(text || `Server error (${response.status})`);
  }

  if (!response.ok) {
    throw new Error((data.error as string) || `Checkout failed (${response.status})`);
  }

  const { url } = data;

  if (!url) {
    throw new Error('No checkout URL received');
  }

  window.location.href = url;
}

export async function createPaymentSession(paymentType: 'lead_unlock' | 'job_access', jobId: string) {
  if (await isTrainingModeActive()) {
    throw new Error('Training Mode is active. Payments are disabled in test mode.');
  }

  const { data: { session } } = await supabase.auth.getSession();

  if (!session) {
    throw new Error('Not authenticated');
  }

  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const apiUrl = `${supabaseUrl}/functions/v1/create-payment-session`;

  const response = await fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${session.access_token}`,
      'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      paymentType,
      jobId,
      successUrl: `${window.location.origin}/jobs?payment=success&type=${paymentType}&job_id=${jobId}`,
      cancelUrl: `${window.location.origin}/jobs?payment=cancelled`,
    }),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Failed to create payment session');
  }

  const { url } = await response.json();

  if (!url) {
    throw new Error('No checkout URL received');
  }

  window.location.href = url;
}

export async function createConnectOnboardingSession() {
  if (await isTrainingModeActive()) {
    throw new Error('Training Mode is active. Stripe Connect is disabled in test mode.');
  }

  const { data: { session } } = await supabase.auth.getSession();

  if (!session) {
    throw new Error('Not authenticated');
  }

  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const apiUrl = `${supabaseUrl}/functions/v1/stripe-connect-onboarding`;

  const response = await fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${session.access_token}`,
      'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      refreshUrl: `${window.location.origin}/dashboard?connect=refresh`,
      returnUrl: `${window.location.origin}/dashboard?connect=success`,
    }),
  });

  const text = await response.text();
  let data: Record<string, unknown>;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error(text || `Server error (${response.status})`);
  }

  if (!response.ok) {
    throw new Error((data.error as string) || `Connect onboarding failed (${response.status})`);
  }

  const { url } = data;

  if (!url) {
    throw new Error('No onboarding URL received');
  }

  window.location.href = url;
}

export async function cancelSubscription(subscriptionId: string) {
  if (await isTrainingModeActive()) {
    throw new Error('Training Mode is active. Use the admin panel to deactivate test subscriptions.');
  }

  const { data: { session } } = await supabase.auth.getSession();

  if (!session) {
    throw new Error('Not authenticated');
  }

  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const apiUrl = `${supabaseUrl}/functions/v1/cancel-subscription`;

  const response = await fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${session.access_token}`,
      'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ subscriptionId }),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Failed to cancel subscription');
  }

  return response.json();
}

export { stripePromise };
