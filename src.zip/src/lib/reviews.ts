import { supabase } from './supabase';

export interface Review {
  id: string;
  job_id: string;
  tradie_id: string;
  client_id: string;
  rating: number;
  comment: string | null;
  created_at: string;
  updated_at: string;
  client?: {
    full_name: string;
  };
}

export interface TradieRating {
  tradie_id: string;
  total_reviews: number;
  average_rating: number;
  five_star_count: number;
  four_star_count: number;
  three_star_count: number;
  two_star_count: number;
  one_star_count: number;
}

export interface PlatformStats {
  total_reviews: number;
  average_rating: number;
  total_tradies_with_reviews: number;
}

export async function getTradieRating(tradieId: string): Promise<TradieRating | null> {
  const { data, error } = await supabase
    .from('tradie_ratings')
    .select('*')
    .eq('tradie_id', tradieId)
    .maybeSingle();

  if (error) {
    return null;
  }

  return data;
}

export async function getTradieReviews(tradieId: string): Promise<Review[]> {
  const { data, error } = await supabase
    .from('reviews')
    .select(`
      *,
      client:profiles!reviews_client_id_fkey(full_name)
    `)
    .eq('tradie_id', tradieId)
    .order('created_at', { ascending: false });

  if (error) {
    return [];
  }

  return data || [];
}

export async function getPlatformStats(): Promise<PlatformStats> {
  const { data: reviews, error } = await supabase
    .from('reviews')
    .select('rating, tradie_id');

  if (error || !reviews || reviews.length === 0) {
    return {
      total_reviews: 0,
      average_rating: 0,
      total_tradies_with_reviews: 0
    };
  }

  const totalReviews = reviews.length;
  const averageRating = reviews.reduce((sum, r) => sum + r.rating, 0) / totalReviews;
  const uniqueTradies = new Set(reviews.map(r => r.tradie_id)).size;

  return {
    total_reviews: totalReviews,
    average_rating: Math.round(averageRating * 10) / 10,
    total_tradies_with_reviews: uniqueTradies
  };
}

export async function canUserReviewJob(jobId: string): Promise<boolean> {
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) return false;

  const { data: job } = await supabase
    .from('jobs')
    .select('status, client_id')
    .eq('id', jobId)
    .maybeSingle();

  if (!job || job.client_id !== user.id || job.status !== 'completed') {
    return false;
  }

  const { data: existingReview } = await supabase
    .from('reviews')
    .select('id')
    .eq('job_id', jobId)
    .eq('client_id', user.id)
    .maybeSingle();

  return !existingReview;
}
