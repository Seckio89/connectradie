import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Calendar,
  Users,
  Clock,
  ChevronLeft,
  ChevronRight,
  Plus,
  X,
  Loader2,
  MessageSquare,
  CheckCircle2,
  AlertCircle,
  XCircle,
  Briefcase,
  RefreshCw,
  Pencil,
  Trash2,
  MoreVertical,
  Copy,
  Settings,
  Crown,
  Bell,
  BellOff,
  BellRing,
  ShieldAlert,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { redactSensitiveInfo } from '../lib/redaction';
import { checkLicenseExpired } from '../lib/utils';
import type { AvailabilitySlot, Job, Message } from '../types/database';
import DashboardLayout from '../components/DashboardLayout';
import BulkAvailabilityModal from '../components/BulkAvailabilityModal';
import ConversationSettingsModal from '../components/ConversationSettingsModal';
import JobManagementModal from '../components/JobManagementModal';
import OnboardingChecklist from '../components/OnboardingChecklist';
import QuoteInsightsWidget from '../components/QuoteInsightsWidget';
import SmartInsightsWidget from '../components/SmartInsightsWidget';
import EmptyState from '../components/EmptyState';
import SubscriptionModal from '../components/SubscriptionModal';
import CollapsibleSection from '../components/CollapsibleSection';
import { DashboardStatsSkeleton, CalendarSkeleton } from '../components/SkeletonLoader';
import { isPro, PRO_FEATURES } from '../lib/subscription';
import { ProBadgeButton } from '../components/ProFeatureGate';
import UserTradeBadges from '../components/UserTradeBadges';
import { requestPushPermission, subscribeToPush, savePushPreferences, getPushPermissionStatus, showUrgentLeadNotification } from '../lib/notifications';

type TabType = 'overview' | 'jobs' | 'messages';

export default function TradieDashboard() {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [slots, setSlots] = useState<AvailabilitySlot[]>([]);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [conversations, setConversations] = useState<any[]>([]);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [loading, setLoading] = useState(true);
  const [showAddSlot, setShowAddSlot] = useState(false);
  const [toast, setToast] = useState<{ message: string; show: boolean; isError?: boolean }>({ message: '', show: false });
  const [unlockedJobIds, setUnlockedJobIds] = useState<string[]>([]);
  const [calendarIntegration, setCalendarIntegration] = useState<any>(null);
  const [syncLoading, setSyncLoading] = useState(false);
  const [editingSlot, setEditingSlot] = useState<AvailabilitySlot | null>(null);
  const [editStartTime, setEditStartTime] = useState('');
  const [editEndTime, setEditEndTime] = useState('');
  const [selectedDay, setSelectedDay] = useState<number | null>(null);
  const [showManageMenu, setShowManageMenu] = useState(false);
  const [showAddSlotForDay, setShowAddSlotForDay] = useState(false);
  const [newSlotStartTime, setNewSlotStartTime] = useState('09:00');
  const [newSlotEndTime, setNewSlotEndTime] = useState('17:00');
  const [confirmClearAll, setConfirmClearAll] = useState(false);
  const [selectedConversation, setSelectedConversation] = useState<any | null>(null);
  const [showConversationSettings, setShowConversationSettings] = useState(false);
  const [selectedJob, setSelectedJob] = useState<string | null>(null);
  const [showJobManagement, setShowJobManagement] = useState(false);
  const [jobToDelete, setJobToDelete] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [addingSlot, setAddingSlot] = useState(false);
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);
  const [pushStatus, setPushStatus] = useState<'loading' | 'granted' | 'denied' | 'default' | 'unsupported'>('loading');
  const [pushEnabling, setPushEnabling] = useState(false);
  const { user, tradieDetails, profile, updateTradieDetails } = useAuth();
  const isProUser = isPro(tradieDetails?.subscription_tier, profile?.is_premium);
  const isLicenseExpired = checkLicenseExpired(profile?.verification_status, profile?.license_expiry);

  const showToast = (message: string, isError = false) => {
    setToast({ message, show: true, isError });
    setTimeout(() => setToast({ message: '', show: false }), 3000);
  };

  useEffect(() => {
    const status = getPushPermissionStatus();
    setPushStatus(status);
  }, []);

  useEffect(() => {
    const isAnyModalOpen = !!(editingSlot || confirmClearAll || showAddSlotForDay || showDeleteConfirm);
    if (isAnyModalOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [editingSlot, confirmClearAll, showAddSlotForDay, showDeleteConfirm]);

  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel('urgent-leads')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'jobs', filter: 'is_flash_boost=eq.true' },
        (payload) => {
          const newJob = payload.new as Job;
          if (pushStatus === 'granted' && profile?.push_enabled) {
            showUrgentLeadNotification(newJob);
          }
          showToast(`New urgent lead posted! Check your leads.`);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, pushStatus, profile?.push_enabled]);

  const handleEnablePush = async () => {
    if (!user) return;
    setPushEnabling(true);

    const permission = await requestPushPermission();
    setPushStatus(permission);

    if (permission === 'granted') {
      const subscription = await subscribeToPush();
      await savePushPreferences(user.id, true, subscription);
      showToast('Desktop alerts enabled! You\'ll be notified of urgent leads.');
    } else if (permission === 'denied') {
      showToast('Notification permission was denied. Check your browser settings.');
    }

    setPushEnabling(false);
  };

  const subscriptionTier = tradieDetails?.subscription_tier;

  useEffect(() => {
    if (user) {
      fetchUnlockedJobs();
      fetchSlots();
      fetchJobs();
      fetchConversations();
      fetchCalendarIntegration();
    }
  }, [user, subscriptionTier, currentDate]);

  const fetchUnlockedJobs = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('job_unlocks')
        .select('job_id')
        .eq('tradie_id', user.id);

      if (error) throw error;

      if (data) {
        setUnlockedJobIds(data.map((j) => j.job_id));
      }
    } catch {
      showToast('Failed to load unlocked jobs. Please refresh.', true);
    }
  };

  const fetchSlots = async () => {
    if (!user) return;
    setLoading(true);

    try {
      const startOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
      const endOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);

      const { data, error } = await supabase
        .from('availability_slots')
        .select('*')
        .eq('tradie_id', user.id)
        .gte('start_time', startOfMonth.toISOString())
        .lte('start_time', endOfMonth.toISOString())
        .order('start_time', { ascending: true });

      if (error) throw error;

      setSlots(data || []);
    } catch {
      showToast('Failed to load availability slots. Please refresh.', true);
    } finally {
      setLoading(false);
    }
  };

  const fetchJobs = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from('jobs')
      .select('*, profiles!jobs_client_id_fkey(full_name, email)')
      .eq('tradie_id', user.id)
      .order('created_at', { ascending: false });

    if (!error && data) {
      setJobs(data);
    }
  };

  const fetchConversations = async () => {
    if (!user) return;

    try {
      const { data: myParticipations, error } = await supabase
        .from('conversation_participants')
        .select(`
          *,
          conversation:conversations(*)
        `)
        .eq('user_id', user.id)
        .is('left_at', null)
        .is('archived_at', null)
        .order('joined_at', { ascending: false });

      if (error) throw error;

      if (myParticipations) {
        const conversationsWithDetails = await Promise.all(
          myParticipations.map(async (mp: any) => {
            const conv = mp.conversation;

            const { data: allParticipants } = await supabase
              .from('conversation_participants')
              .select('*, profile:profiles(*)')
              .eq('conversation_id', conv.id)
              .is('left_at', null);

            const { data: messages } = await supabase
              .from('messages')
              .select('*, sender_profile:profiles!messages_sender_id_fkey(full_name, email)')
              .eq('conversation_id', conv.id)
              .is('deleted_at', null)
              .order('created_at', { ascending: true });

            return {
              ...conv,
              participants: allParticipants || [],
              lastMessage: messages && messages.length > 0 ? messages[messages.length - 1] : undefined,
              messages: messages || [],
              myParticipation: mp,
              otherParticipants: (allParticipants || []).filter((p: any) => p.user_id !== user.id),
            };
          })
        );

        conversationsWithDetails.sort((a, b) =>
          new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime()
        );

        setConversations(conversationsWithDetails);
      }
    } catch {
      showToast('Failed to load conversations. Please refresh.', true);
    }
  };

  const fetchCalendarIntegration = async () => {
    if (!user) return;

    const { data } = await supabase
      .from('calendar_integrations')
      .select('*')
      .eq('tradie_id', user.id)
      .eq('provider', 'google')
      .maybeSingle();

    setCalendarIntegration(data);
  };

  const handleSyncCalendar = async () => {
    if (!user) return;

    setSyncLoading(true);

    try {
      // If no integration exists, initiate OAuth
      if (!calendarIntegration) {
        const { data: session } = await supabase.auth.getSession();
        if (!session.session) {
          setToast({ message: 'Please log in again', show: true });
          setTimeout(() => setToast({ message: '', show: false }), 3000);
          setSyncLoading(false);
          return;
        }

        const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/google-calendar-oauth?action=initiate`;
        const response = await fetch(apiUrl, {
          headers: {
            'Authorization': `Bearer ${session.session.access_token}`,
            'Content-Type': 'application/json',
          },
        });

        const result = await response.json();

        if (result.authUrl) {
          // Open OAuth window
          const width = 600;
          const height = 700;
          const left = window.screenX + (window.outerWidth - width) / 2;
          const top = window.screenY + (window.outerHeight - height) / 2;
          const authWindow = window.open(
            result.authUrl,
            'Google Calendar Authorization',
            `width=${width},height=${height},left=${left},top=${top}`
          );

          // Poll for window close
          const checkWindow = setInterval(() => {
            if (authWindow?.closed) {
              clearInterval(checkWindow);
              fetchCalendarIntegration();
              setToast({ message: 'Calendar connected successfully!', show: true });
              setTimeout(() => setToast({ message: '', show: false }), 3000);
              setSyncLoading(false);
            }
          }, 500);
        }
      } else {
        // Sync existing integration
        const { data: session } = await supabase.auth.getSession();
        if (!session.session) {
          setToast({ message: 'Please log in again', show: true });
          setTimeout(() => setToast({ message: '', show: false }), 3000);
          setSyncLoading(false);
          return;
        }

        const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/sync-google-calendar`;
        const response = await fetch(apiUrl, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.session.access_token}`,
            'Content-Type': 'application/json',
          },
        });

        const result = await response.json();

        if (result.success) {
          setToast({
            message: `Calendar synced! ${result.slotsRemoved} conflicting slot(s) removed.`,
            show: true
          });
          setTimeout(() => setToast({ message: '', show: false }), 3000);
          fetchSlots();
        } else {
          setToast({ message: result.error || 'Sync failed', show: true });
          setTimeout(() => setToast({ message: '', show: false }), 3000);
        }

        setSyncLoading(false);
      }
    } catch (error) {
      setToast({ message: 'Failed to sync calendar', show: true });
      setTimeout(() => setToast({ message: '', show: false }), 3000);
      setSyncLoading(false);
    }
  };

  const handleAddSlot = async (slots: Array<{ date: string; startTime: string; endTime: string }>) => {
    if (!user || slots.length === 0) return;

    const slotsToInsert = slots.map((slot) => ({
      tradie_id: user.id,
      start_time: new Date(`${slot.date}T${slot.startTime}`).toISOString(),
      end_time: new Date(`${slot.date}T${slot.endTime}`).toISOString(),
      status: 'available',
    }));

    const { error } = await supabase.from('availability_slots').insert(slotsToInsert);

    if (!error) {
      setShowAddSlot(false);
      setToast({
        message: `Successfully added ${slots.length} slot${slots.length !== 1 ? 's' : ''} to your calendar`,
        show: true
      });
      setTimeout(() => {
        setToast({ message: '', show: false });
      }, 3000);
      fetchSlots();
    }
  };

  const handleDeleteSlot = async (slotId: string) => {
    try {
      const { error } = await supabase.from('availability_slots').delete().eq('id', slotId);
      if (error) throw error;
      fetchSlots();
    } catch {
      showToast('Failed to delete slot. Please try again.', true);
    }
  };

  const handleClearAllUpcoming = async () => {
    if (!user) return;
    try {
      const now = new Date().toISOString();
      const { error } = await supabase
        .from('availability_slots')
        .delete()
        .eq('tradie_id', user.id)
        .eq('status', 'available')
        .gte('start_time', now);
      if (error) throw error;
      fetchSlots();
      setConfirmClearAll(false);
      setShowManageMenu(false);
      showToast('All upcoming available slots cleared');
    } catch {
      showToast('Failed to clear slots. Please try again.', true);
    }
  };

  const handleRemoveDuplicates = async () => {
    if (!user) return;
    try {
      const { data: allSlots, error: fetchError } = await supabase
        .from('availability_slots')
        .select('*')
        .eq('tradie_id', user.id)
        .eq('status', 'available')
        .order('start_time', { ascending: true });

      if (fetchError) throw fetchError;

      if (!allSlots || allSlots.length === 0) {
        showToast('No duplicates found');
        setShowManageMenu(false);
        return;
      }

      const seen = new Map<string, string>();
      const duplicateIds: string[] = [];

      allSlots.forEach((slot) => {
        const key = `${slot.start_time}-${slot.end_time}`;
        if (seen.has(key)) {
          duplicateIds.push(slot.id);
        } else {
          seen.set(key, slot.id);
        }
      });

      if (duplicateIds.length === 0) {
        showToast('No duplicates found');
        setShowManageMenu(false);
        return;
      }

      const { error: deleteError } = await supabase
        .from('availability_slots')
        .delete()
        .in('id', duplicateIds);

      if (deleteError) throw deleteError;

      fetchSlots();
      setShowManageMenu(false);
      showToast(`Removed ${duplicateIds.length} duplicate slot(s)`);
    } catch {
      showToast('Failed to remove duplicates. Please try again.', true);
    }
  };

  const handleAddSlotForDay = async () => {
    if (!user || selectedDay === null) return;
    setAddingSlot(true);

    try {
      const slotDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), selectedDay);
      const startTime = new Date(slotDate);
      const endTime = new Date(slotDate);

      const [startHour, startMin] = newSlotStartTime.split(':').map(Number);
      const [endHour, endMin] = newSlotEndTime.split(':').map(Number);

      startTime.setHours(startHour, startMin, 0, 0);
      endTime.setHours(endHour, endMin, 0, 0);

      const { error } = await supabase.from('availability_slots').insert({
        tradie_id: user.id,
        start_time: startTime.toISOString(),
        end_time: endTime.toISOString(),
        status: 'available',
      });

      if (error) {
        showToast('Failed to add slot. Please try again.', true);
        return;
      }

      fetchSlots();
      setShowAddSlotForDay(false);
      setNewSlotStartTime('09:00');
      setNewSlotEndTime('17:00');
      showToast('Slot added successfully');
    } catch {
      showToast('Something went wrong. Please try again.', true);
    } finally {
      setAddingSlot(false);
    }
  };

  const startEditingSlot = (slot: AvailabilitySlot) => {
    setEditingSlot(slot);
    const startDate = new Date(slot.start_time);
    const endDate = new Date(slot.end_time);
    setEditStartTime(
      `${startDate.getHours().toString().padStart(2, '0')}:${startDate.getMinutes().toString().padStart(2, '0')}`
    );
    setEditEndTime(
      `${endDate.getHours().toString().padStart(2, '0')}:${endDate.getMinutes().toString().padStart(2, '0')}`
    );
  };

  const handleUpdateSlot = async () => {
    if (!editingSlot) return;

    try {
      const slotDate = new Date(editingSlot.start_time);
      const [startHour, startMin] = editStartTime.split(':').map(Number);
      const [endHour, endMin] = editEndTime.split(':').map(Number);

      const newStartTime = new Date(slotDate);
      newStartTime.setHours(startHour, startMin, 0, 0);

      const newEndTime = new Date(slotDate);
      newEndTime.setHours(endHour, endMin, 0, 0);

      const { error } = await supabase
        .from('availability_slots')
        .update({
          start_time: newStartTime.toISOString(),
          end_time: newEndTime.toISOString(),
        })
        .eq('id', editingSlot.id);

      if (error) throw error;

      setEditingSlot(null);
      fetchSlots();
      showToast('Slot updated successfully');
    } catch {
      showToast('Failed to update slot. Please try again.', true);
    }
  };

  const handleDeleteJob = async () => {
    if (!jobToDelete) return;

    setDeleting(true);

    try {
      const { error } = await supabase
        .from('jobs')
        .delete()
        .eq('id', jobToDelete);

      if (error) throw error;

      setJobs(prevJobs => prevJobs.filter(job => job.id !== jobToDelete));

      setShowDeleteConfirm(false);
      setJobToDelete(null);
      showToast('Job deleted successfully');
    } catch (error) {
      showToast('Failed to delete job');
    } finally {
      setDeleting(false);
    }
  };

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDay = firstDay.getDay();
    return { daysInMonth, startingDay };
  };

  const { daysInMonth, startingDay } = getDaysInMonth(currentDate);

  const getSlotsForDate = (day: number) => {
    const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
    return slots.filter((slot) => {
      const slotDate = new Date(slot.start_time);
      return (
        slotDate.getDate() === date.getDate() &&
        slotDate.getMonth() === date.getMonth() &&
        slotDate.getFullYear() === date.getFullYear()
      );
    });
  };

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const totalAvailableHours = slots
    .filter((s) => s.status === 'available')
    .reduce((acc, slot) => {
      const start = new Date(slot.start_time);
      const end = new Date(slot.end_time);
      return acc + (end.getTime() - start.getTime()) / (1000 * 60 * 60);
    }, 0);

  const bookedSlots = slots.filter((s) => s.status === 'booked').length;

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-5 h-5 text-green-600" />;
      case 'in_progress':
        return <Clock className="w-5 h-5 text-blue-600" />;
      case 'cancelled':
        return <XCircle className="w-5 h-5 text-red-600" />;
      default:
        return <AlertCircle className="w-5 h-5 text-amber-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'in_progress':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'cancelled':
        return 'bg-red-100 text-red-700 border-red-200';
      case 'accepted':
        return 'bg-teal-100 text-teal-700 border-teal-200';
      default:
        return 'bg-amber-100 text-amber-700 border-amber-200';
    }
  };

  return (
    <DashboardLayout>
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Your Business Hub</h1>
          <p className="text-gray-700">Manage your schedule, jobs, and conversations in one place</p>
          {profile && (
            <div className="mt-3">
              <UserTradeBadges
                verifiedTrades={profile.verified_trades || []}
                declaredTrades={profile.declared_trades || []}
              />
            </div>
          )}
        </div>

        {isLicenseExpired && (
          <div className="mb-6 bg-red-50 border-2 border-red-300 rounded-2xl p-5">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center flex-shrink-0">
                <ShieldAlert className="w-6 h-6 text-red-600" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-red-900 text-lg">License Expired</h3>
                <p className="text-red-800 mt-1">
                  Your trade license expired
                  {profile?.license_expiry && (
                    <> on <span className="font-semibold">{new Date(profile.license_expiry).toLocaleDateString('en-AU', { day: 'numeric', month: 'long', year: 'numeric' })}</span></>
                  )}
                  . Your account has been unverified and you cannot accept jobs or submit quotes until your license is renewed.
                </p>
                <Link
                  to="/settings"
                  className="inline-flex items-center gap-2 mt-3 px-5 py-2.5 bg-red-600 text-white font-semibold rounded-xl hover:bg-red-700 transition-colors"
                >
                  <Settings className="w-4 h-4" />
                  Upload Renewed License
                </Link>
              </div>
            </div>
          </div>
        )}

        <CollapsibleSection
          title="Quick Stats"
          defaultOpen={true}
          icon={<div className="w-7 h-7 bg-primary-100 rounded-lg flex items-center justify-center"><Clock className="w-4 h-4 text-primary-600" /></div>}
        >
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-gradient-to-br from-primary-50 to-primary-100/30 rounded-2xl border border-primary-200 p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-primary-200 rounded-xl flex items-center justify-center">
                <Clock className="w-6 h-6 text-primary-700" />
              </div>
              <div>
                <p className="text-sm text-primary-700 font-medium">Available Hours</p>
                <p className="text-3xl font-bold text-primary-900">{totalAvailableHours.toFixed(0)}</p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-green-50 to-green-100/30 rounded-2xl border border-green-200 p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-green-200 rounded-xl flex items-center justify-center">
                <Calendar className="w-6 h-6 text-green-700" />
              </div>
              <div>
                <p className="text-sm text-green-700 font-medium">Booked Slots</p>
                <p className="text-3xl font-bold text-green-900">{bookedSlots}</p>
              </div>
            </div>
          </div>

          <Link to="/jobs" className="bg-gradient-to-br from-amber-50 to-amber-100/30 rounded-2xl border border-amber-200 p-6 hover:border-amber-300 hover:shadow-lg transition-all cursor-pointer">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-amber-200 rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6 text-amber-700" />
              </div>
              <div>
                <p className="text-sm text-amber-700 font-medium">Active Jobs</p>
                <p className="text-3xl font-bold text-amber-900">{jobs.filter((j) => j.status === 'in_progress').length}</p>
              </div>
            </div>
          </Link>

          <button
            onClick={() => setShowSubscriptionModal(true)}
            className={`rounded-2xl border p-6 hover:shadow-lg transition-all cursor-pointer text-left ${
              isProUser
                ? 'bg-gradient-to-br from-amber-50 to-yellow-100/30 border-amber-300'
                : 'bg-gradient-to-br from-gray-50 to-gray-100/30 border-gray-200 hover:border-amber-300'
            }`}
          >
            <div className="flex items-center gap-4">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                isProUser ? 'bg-amber-200' : 'bg-gray-200'
              }`}>
                <Crown className={`w-6 h-6 ${isProUser ? 'text-amber-700' : 'text-gray-500'}`} />
              </div>
              <div className="flex-1">
                <p className={`text-sm font-medium ${isProUser ? 'text-amber-700' : 'text-gray-600'}`}>
                  Your Plan
                </p>
                <p className={`text-xl font-bold ${isProUser ? 'text-amber-900' : 'text-gray-900'}`}>
                  {isProUser ? 'Pro' : 'Free'}
                </p>
                {!isProUser && (
                  <p className="text-xs text-amber-600 font-medium mt-1">Upgrade for more</p>
                )}
              </div>
            </div>
          </button>
        </div>
        </CollapsibleSection>

        <div className="mt-6">
          <SmartInsightsWidget />
        </div>

        <div className="mt-6 flex items-center gap-2 px-4 py-3 bg-green-50 border border-green-200 rounded-xl">
          <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
          <span className="text-sm font-semibold text-green-800">100% Payout (Zero Platform Fees)</span>
          <span className="text-sm text-green-600">- You keep every dollar you earn.</span>
        </div>

        <div className="mt-6 space-y-6">
        <QuoteInsightsWidget />
        <OnboardingChecklist />

        </div>

        {pushStatus !== 'granted' && pushStatus !== 'unsupported' && (
          <div className="bg-gradient-to-r from-blue-50 to-sky-50 rounded-2xl border border-blue-200 p-5 mb-6 mt-6">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center flex-shrink-0">
                  <BellRing className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">Never Miss an Urgent Lead</h3>
                  <p className="text-sm text-gray-600 mt-0.5">
                    Get instant desktop alerts when high-priority jobs are posted in your area.
                  </p>
                </div>
              </div>
              <button
                onClick={handleEnablePush}
                disabled={pushEnabling || pushStatus === 'denied'}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-sm transition-all flex-shrink-0 ${
                  pushStatus === 'denied'
                    ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                    : 'bg-blue-600 text-white hover:bg-blue-700 shadow-sm hover:shadow-md active:scale-95'
                }`}
              >
                {pushEnabling ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : pushStatus === 'denied' ? (
                  <BellOff className="w-4 h-4" />
                ) : (
                  <Bell className="w-4 h-4" />
                )}
                {pushStatus === 'denied' ? 'Blocked in Browser' : 'Enable Desktop Alerts'}
              </button>
            </div>
          </div>
        )}

        {pushStatus === 'granted' && (
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl border border-green-200 p-4 mb-6 mt-6">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
              <p className="text-sm font-medium text-green-800">Desktop alerts are active. You'll be notified of urgent leads instantly.</p>
            </div>
          </div>
        )}

        <div className="bg-white rounded-2xl border border-gray-200 mb-6 shadow-sm mt-8">
          <div className="border-b border-gray-200">
            <div className="flex gap-2 p-4">
              <button
                onClick={() => setActiveTab('overview')}
                className={`flex items-center gap-2 px-5 py-3 rounded-xl font-semibold transition-all min-h-[44px] ${
                  activeTab === 'overview'
                    ? 'bg-primary-600 text-white shadow-md'
                    : 'text-gray-600 hover:bg-gray-50 active:scale-95'
                }`}
              >
                <Calendar className="w-5 h-5" />
                Overview
              </button>
              <button
                onClick={() => setActiveTab('jobs')}
                className={`flex items-center gap-2 px-5 py-3 rounded-xl font-semibold transition-all min-h-[44px] ${
                  activeTab === 'jobs'
                    ? 'bg-primary-600 text-white shadow-md'
                    : 'text-gray-600 hover:bg-gray-50 active:scale-95'
                }`}
              >
                <Briefcase className="w-5 h-5" />
                Jobs
              </button>
              <button
                onClick={() => setActiveTab('messages')}
                className={`flex items-center gap-2 px-5 py-3 rounded-xl font-semibold transition-all min-h-[44px] ${
                  activeTab === 'messages'
                    ? 'bg-primary-600 text-white shadow-md'
                    : 'text-gray-600 hover:bg-gray-50 active:scale-95'
                }`}
              >
                <MessageSquare className="w-5 h-5" />
                Messages
              </button>
            </div>
          </div>

          <div className="p-6">
            {activeTab === 'overview' && (
              <div className="grid lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-4">
                      <button
                        onClick={() => {
                          setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
                          setSelectedDay(null);
                        }}
                        className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                      >
                        <ChevronLeft className="w-5 h-5 text-gray-600" />
                      </button>
                      <h2 className="text-lg font-semibold text-gray-900">
                        {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
                      </h2>
                      <button
                        onClick={() => {
                          setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));
                          setSelectedDay(null);
                        }}
                        className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                      >
                        <ChevronRight className="w-5 h-5 text-gray-600" />
                      </button>
                    </div>

                    <div className="flex items-center gap-2">
                      {isProUser ? (
                        <button
                          onClick={() => setShowAddSlot(true)}
                          className="flex items-center gap-2 px-4 py-2 bg-primary-600 text-white font-medium rounded-xl hover:bg-primary-700 transition-colors min-h-[44px]"
                        >
                          <Plus className="w-4 h-4" />
                          Bulk Add Slots
                        </button>
                      ) : (
                        <button
                          onClick={() => setShowSubscriptionModal(true)}
                          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 text-white font-medium rounded-xl hover:from-amber-600 hover:to-amber-700 transition-all min-h-[44px]"
                        >
                          <Crown className="w-4 h-4" />
                          Bulk Add Slots
                          <span className="text-[10px] font-bold bg-white/20 px-1.5 py-0.5 rounded">PRO</span>
                        </button>
                      )}
                      {isProUser ? (
                        <button
                          onClick={handleSyncCalendar}
                          disabled={syncLoading}
                          className="flex items-center gap-2 px-4 py-2 border border-gray-200 text-gray-700 font-medium rounded-xl hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed min-h-[44px]"
                        >
                          {syncLoading ? (
                            <>
                              <Loader2 className="w-4 h-4 animate-spin" />
                              {calendarIntegration ? 'Syncing...' : 'Connecting...'}
                            </>
                          ) : (
                            <>
                              {calendarIntegration ? (
                                <>
                                  <RefreshCw className="w-4 h-4" />
                                  Sync Google Calendar
                                </>
                              ) : (
                                <>
                                  <Calendar className="w-4 h-4" />
                                  Connect Google Calendar
                                </>
                              )}
                            </>
                          )}
                        </button>
                      ) : (
                        <button
                          onClick={() => setShowSubscriptionModal(true)}
                          className="flex items-center gap-2 px-4 py-2 border border-amber-300 text-amber-700 font-medium rounded-xl hover:bg-amber-50 transition-colors min-h-[44px]"
                        >
                          <Calendar className="w-4 h-4" />
                          Google Calendar
                          <span className="text-[10px] font-bold bg-amber-100 text-amber-600 px-1.5 py-0.5 rounded">PRO</span>
                        </button>
                      )}
                      <div className="relative">
                        <button
                          onClick={() => setShowManageMenu(!showManageMenu)}
                          className="p-2 border border-gray-200 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors"
                        >
                          <MoreVertical className="w-5 h-5" />
                        </button>
                        {showManageMenu && (
                          <>
                            <div
                              className="fixed inset-0 z-10"
                              onClick={() => setShowManageMenu(false)}
                            />
                            <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-lg border border-gray-200 z-20 py-2">
                              <button
                                onClick={handleRemoveDuplicates}
                                className="w-full px-4 py-2.5 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-3"
                              >
                                <Copy className="w-4 h-4 text-gray-400" />
                                Remove Duplicates
                              </button>
                              <button
                                onClick={() => setConfirmClearAll(true)}
                                className="w-full px-4 py-2.5 text-left text-sm text-red-600 hover:bg-red-50 flex items-center gap-3"
                              >
                                <Trash2 className="w-4 h-4" />
                                Clear All Upcoming
                              </button>
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {loading ? (
                    <div className="flex items-center justify-center py-12">
                      <Loader2 className="w-8 h-8 text-primary-600 animate-spin" />
                    </div>
                  ) : (
                    <>
                      <div className="grid grid-cols-7 gap-1 mb-2">
                        {dayNames.map((day) => (
                          <div key={day} className="text-center text-xs font-medium text-gray-500 py-2">
                            {day}
                          </div>
                        ))}
                      </div>

                      <div className="grid grid-cols-7 gap-1">
                        {[...Array(startingDay)].map((_, i) => (
                          <div key={`empty-${i}`} className="aspect-square" />
                        ))}

                        {[...Array(daysInMonth)].map((_, i) => {
                          const day = i + 1;
                          const daySlots = getSlotsForDate(day);
                          const hasAvailable = daySlots.some((s) => s.status === 'available');
                          const hasBooked = daySlots.some((s) => s.status === 'booked');
                          const isToday = new Date().getDate() === day &&
                            new Date().getMonth() === currentDate.getMonth() &&
                            new Date().getFullYear() === currentDate.getFullYear();
                          const isSelected = selectedDay === day;

                          return (
                            <button
                              key={day}
                              onClick={() => setSelectedDay(day)}
                              className={`aspect-square rounded-lg p-1 text-sm transition-all min-w-[40px] min-h-[40px] ${
                                isSelected
                                  ? 'bg-primary-600 text-white ring-2 ring-primary-600 ring-offset-2'
                                  : hasAvailable && hasBooked
                                  ? 'bg-gradient-to-br from-green-50 to-blue-50 hover:from-green-100 hover:to-blue-100'
                                  : hasAvailable
                                  ? 'bg-green-50 hover:bg-green-100'
                                  : hasBooked
                                  ? 'bg-blue-50 hover:bg-blue-100'
                                  : isToday
                                  ? 'ring-2 ring-primary-500 hover:bg-gray-100'
                                  : 'hover:bg-gray-100'
                              }`}
                            >
                              <div className="h-full flex flex-col items-center justify-center">
                                <span className={`text-sm ${
                                  isSelected
                                    ? 'font-bold text-white'
                                    : isToday
                                    ? 'font-bold text-primary-600'
                                    : hasAvailable
                                    ? 'font-semibold text-green-800'
                                    : hasBooked
                                    ? 'font-semibold text-blue-800'
                                    : 'text-gray-700'
                                }`}>
                                  {day}
                                </span>
                                <div className="flex gap-1 mt-0.5">
                                  {hasAvailable && <span className={`w-2 h-2 rounded-full ${isSelected ? 'bg-green-300' : 'bg-green-500'}`} />}
                                  {hasBooked && <span className={`w-2 h-2 rounded-full ${isSelected ? 'bg-blue-300' : 'bg-primary-500'}`} />}
                                </div>
                              </div>
                            </button>
                          );
                        })}
                      </div>

                      <div className="mt-4 flex items-center gap-5 text-sm text-gray-700">
                        <div className="flex items-center gap-2">
                          <span className="w-4 h-4 bg-green-100 border-2 border-green-500 rounded" />
                          <span className="font-medium">Available</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="w-4 h-4 bg-blue-100 border-2 border-primary-500 rounded" />
                          <span className="font-medium">Booked</span>
                        </div>
                      </div>
                    </>
                  )}
                </div>

                <div className="bg-gray-50 rounded-xl p-4">
                  <h3 className="font-semibold text-gray-900 mb-4">
                    {selectedDay
                      ? new Date(currentDate.getFullYear(), currentDate.getMonth(), selectedDay).toLocaleDateString('en-AU', {
                          weekday: 'long',
                          day: 'numeric',
                          month: 'long',
                        })
                      : 'Upcoming Slots'}
                  </h3>

                  {selectedDay && (
                    <button
                      onClick={() => !isLicenseExpired && setShowAddSlotForDay(true)}
                      disabled={isLicenseExpired}
                      className={`w-full mb-4 flex items-center justify-center gap-2 px-4 py-2.5 border-2 border-dashed rounded-xl transition-all ${
                        isLicenseExpired
                          ? 'border-gray-200 text-gray-400 cursor-not-allowed bg-gray-50'
                          : 'border-gray-300 text-gray-600 hover:border-primary-400 hover:text-primary-600 hover:bg-primary-50'
                      }`}
                      title={isLicenseExpired ? 'License expired - renew to add slots' : ''}
                    >
                      <Plus className="w-4 h-4" />
                      Add time slot
                    </button>
                  )}

                  <div className="space-y-3 max-h-80 overflow-y-auto">
                    {(selectedDay
                      ? getSlotsForDate(selectedDay)
                      : slots.filter((s) => new Date(s.start_time) > new Date()).slice(0, 10)
                    ).map((slot) => (
                      <div
                        key={slot.id}
                        className={`p-3 rounded-xl border ${
                          slot.status === 'available'
                            ? 'bg-green-50 border-green-200'
                            : slot.status === 'booked'
                            ? 'bg-primary-50 border-primary-200'
                            : 'bg-gray-50 border-gray-200'
                        }`}
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            {!selectedDay && (
                              <p className="font-medium text-gray-900 text-sm">
                                {new Date(slot.start_time).toLocaleDateString('en-AU', {
                                  weekday: 'short',
                                  day: 'numeric',
                                  month: 'short',
                                })}
                              </p>
                            )}
                            <p className={`text-gray-600 ${selectedDay ? 'text-sm font-medium text-gray-900' : 'text-xs mt-0.5'}`}>
                              {new Date(slot.start_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              {' - '}
                              {new Date(slot.end_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </p>
                          </div>
                          {slot.status === 'available' && (
                            <div className="flex items-center gap-1">
                              <button
                                onClick={() => startEditingSlot(slot)}
                                className="p-2.5 text-gray-500 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors min-w-[44px] min-h-[44px] flex items-center justify-center"
                                title="Edit time"
                              >
                                <Pencil className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleDeleteSlot(slot.id)}
                                className="p-2.5 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors min-w-[44px] min-h-[44px] flex items-center justify-center"
                                title="Delete slot"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                          )}
                        </div>
                        <span
                          className={`mt-2 inline-block text-xs px-2 py-0.5 rounded-full ${
                            slot.status === 'available'
                              ? 'bg-green-100 text-green-700'
                              : slot.status === 'booked'
                              ? 'bg-primary-100 text-primary-700'
                              : 'bg-gray-100 text-gray-700'
                          }`}
                        >
                          {slot.status}
                        </span>
                      </div>
                    ))}

                    {selectedDay && getSlotsForDate(selectedDay).length === 0 && (
                      <div className="text-center py-6 bg-gray-50 rounded-lg border border-dashed border-gray-300">
                        <p className="text-gray-600 text-sm font-medium mb-2">No slots for this day</p>
                        <p className="text-gray-600 text-xs">Add one above to let clients know you're available</p>
                      </div>
                    )}

                    {!selectedDay && slots.filter((s) => new Date(s.start_time) > new Date()).length === 0 && (
                      <div className="text-center py-6 bg-amber-50 rounded-lg border border-amber-200">
                        <p className="text-amber-900 text-sm font-medium mb-2">No upcoming availability</p>
                        <p className="text-amber-800 text-xs">Add slots to your calendar so clients can book you</p>
                      </div>
                    )}
                  </div>

                  {selectedDay && (
                    <button
                      onClick={() => setSelectedDay(null)}
                      className="w-full mt-3 text-sm text-gray-500 hover:text-gray-700 py-2"
                    >
                      Show all upcoming slots
                    </button>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'jobs' && (
              <div>
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Your Jobs</h2>
                {jobs.length === 0 ? (
                  <EmptyState
                    icon={Briefcase}
                    title="No Active Jobs"
                    description="Set up your calendar so clients can find and book you for their next project."
                    actionLabel="Set Your Availability"
                    onAction={() => setActiveTab('overview')}
                  />
                ) : (
                  <div className="space-y-4">
                    {jobs.map((job: any) => {
                      const getPriorityBadge = () => {
                        if (job.priority === 'urgent') {
                          return (
                            <span className="px-2 py-1 bg-red-100 text-red-700 text-xs font-semibold rounded-full border border-red-200 flex items-center gap-1">
                              <AlertCircle className="w-3 h-3" />
                              URGENT
                            </span>
                          );
                        }
                        return null;
                      };

                      return (
                        <div
                          key={job.id}
                          className={`border rounded-xl p-4 transition-all ${
                            job.priority === 'urgent'
                              ? 'border-red-300 bg-red-50/30'
                              : 'border-gray-200 hover:border-primary-300'
                          }`}
                        >
                          <div className="flex items-start justify-between mb-3">
                            <div className="flex items-center gap-3">
                              {getStatusIcon(job.status)}
                              <div>
                                <div className="flex items-center gap-2 mb-1">
                                  <h3 className="font-semibold text-gray-900">
                                    {job.profiles?.full_name || 'Client'}
                                  </h3>
                                  {getPriorityBadge()}
                                  {job.is_delayed && (
                                    <span className="px-2 py-1 bg-yellow-100 text-yellow-700 text-xs font-medium rounded-full border border-yellow-200 flex items-center gap-1">
                                      <Clock className="w-3 h-3" />
                                      Delayed
                                    </span>
                                  )}
                                </div>
                                <p className="text-sm text-gray-600">
                                  {redactSensitiveInfo(job.profiles?.email || '', unlockedJobIds.includes(job.id))}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(job.status)}`}>
                                {job.status.replaceAll('_', ' ')}
                              </span>
                              <button
                                onClick={() => {
                                  if (!isLicenseExpired) {
                                    setSelectedJob(job.id);
                                    setShowJobManagement(true);
                                  }
                                }}
                                disabled={isLicenseExpired}
                                className={`p-2 rounded-lg transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center ${
                                  isLicenseExpired
                                    ? 'text-gray-300 cursor-not-allowed'
                                    : 'text-gray-400 hover:text-gray-600 hover:bg-gray-100'
                                }`}
                                title={isLicenseExpired ? 'License expired - renew to manage jobs' : 'Manage job'}
                              >
                                <Settings className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                          <p className="text-gray-700 mb-3">
                            {redactSensitiveInfo(job.description, unlockedJobIds.includes(job.id))}
                          </p>
                          {job.notes && (
                            <div className="mb-3 p-2 bg-blue-50 border border-blue-200 rounded-lg">
                              <p className="text-xs text-blue-700">
                                <span className="font-semibold">Note:</span> {job.notes}
                              </p>
                            </div>
                          )}
                          <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600">
                            {job.scheduled_time && (
                              <div className="flex items-center gap-2">
                                <Clock className="w-4 h-4" />
                                {new Date(job.scheduled_time).toLocaleString()}
                              </div>
                            )}
                            {job.is_delayed && job.delayed_until && (
                              <div className="flex items-center gap-2 text-yellow-700">
                                <Clock className="w-4 h-4" />
                                Until {new Date(job.delayed_until).toLocaleString()}
                              </div>
                            )}
                            <div className="flex items-center gap-2 text-xs text-gray-400">
                              <Calendar className="w-3 h-3" />
                              Created {new Date(job.created_at).toLocaleDateString()}
                            </div>
                          </div>
                          {job.status === 'declined' && (
                            <div className="mt-4 pt-4 border-t border-gray-200">
                              <button
                                onClick={() => {
                                  setJobToDelete(job.id);
                                  setShowDeleteConfirm(true);
                                }}
                                className="px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-lg hover:bg-red-700 transition-colors flex items-center gap-2"
                              >
                                <Trash2 className="w-4 h-4" />
                                Delete
                              </button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'messages' && (
              <div>
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Conversations</h2>
                {conversations.length === 0 ? (
                  <EmptyState
                    icon={MessageSquare}
                    title="No Messages Yet"
                    description="When clients message you about jobs, their conversations will appear here."
                    actionLabel="Set Your Availability"
                    onAction={() => setActiveTab('overview')}
                  />
                ) : (
                  <div className="space-y-3">
                    {conversations.map((conv) => {
                      const getConversationTitle = () => {
                        if (conv.title) return conv.title;
                        if (conv.is_group) {
                          return conv.otherParticipants.map((p: any) => p.profile?.full_name || 'Unknown').join(', ');
                        }
                        return conv.otherParticipants[0]?.profile?.full_name || 'Unknown User';
                      };

                      const getConversationInitial = () => {
                        if (conv.is_group) return 'G';
                        return conv.otherParticipants[0]?.profile?.full_name?.charAt(0) || '?';
                      };

                      return (
                        <div
                          key={conv.id}
                          role="button"
                          tabIndex={0}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === ' ') {
                              e.preventDefault();
                              setSelectedConversation(conv);
                              setShowConversationSettings(true);
                            }
                          }}
                          onClick={() => {
                            setSelectedConversation(conv);
                            setShowConversationSettings(true);
                          }}
                          className="border border-gray-200 rounded-xl p-4 hover:border-primary-300 transition-colors cursor-pointer focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2"
                        >
                          <div className="flex items-start gap-3">
                            <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center flex-shrink-0">
                              <span className="text-sm font-bold text-primary-600">
                                {getConversationInitial()}
                              </span>
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between mb-1">
                                <h3 className="font-semibold text-gray-900">
                                  {getConversationTitle()}
                                </h3>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedConversation(conv);
                                    setShowConversationSettings(true);
                                  }}
                                  className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center"
                                >
                                  <Settings className="w-4 h-4" />
                                </button>
                              </div>
                              {conv.lastMessage && (
                                <>
                                  <p className="text-sm text-gray-600 truncate">
                                    {redactSensitiveInfo(conv.lastMessage.content, false)}
                                  </p>
                                  <span className="text-xs text-gray-400 mt-1">
                                    {new Date(conv.lastMessage.created_at).toLocaleDateString()}
                                  </span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      <BulkAvailabilityModal
        isOpen={showAddSlot}
        onClose={() => setShowAddSlot(false)}
        onSave={handleAddSlot}
        currentMonth={currentDate}
      />

      {editingSlot && (
        <>
          <div
            className="fixed inset-0 bg-black/30  z-40"
            onClick={() => setEditingSlot(null)}
            onKeyDown={(e) => { if (e.key === 'Escape') setEditingSlot(null); }}
          />
          <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-white rounded-2xl shadow-2xl z-50 w-full max-w-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-900">Edit Time Slot</h3>
              <button
                onClick={() => setEditingSlot(null)}
                className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mb-4">
              <p className="text-sm text-gray-600 mb-4">
                {new Date(editingSlot.start_time).toLocaleDateString('en-AU', {
                  weekday: 'long',
                  day: 'numeric',
                  month: 'long',
                  year: 'numeric',
                })}
              </p>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Start Time</label>
                  <input
                    type="time"
                    step="300"
                    value={editStartTime}
                    onChange={(e) => setEditStartTime(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">End Time</label>
                  <input
                    type="time"
                    step="300"
                    value={editEndTime}
                    onChange={(e) => setEditEndTime(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                </div>
              </div>
              <p className="text-xs text-gray-400 mt-2">Select times in 5-minute intervals</p>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setEditingSlot(null)}
                className="flex-1 px-4 py-3 text-gray-700 font-medium border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleUpdateSlot}
                className="flex-1 px-4 py-3 bg-primary-600 text-white font-semibold rounded-xl hover:bg-primary-700 transition-colors"
              >
                Save Changes
              </button>
            </div>
          </div>
        </>
      )}

      {confirmClearAll && (
        <>
          <div
            className="fixed inset-0 bg-black/30  z-40"
            onClick={() => setConfirmClearAll(false)}
            onKeyDown={(e) => { if (e.key === 'Escape') setConfirmClearAll(false); }}
          />
          <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-white rounded-2xl shadow-2xl z-50 w-full max-w-md p-6">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                <Trash2 className="w-6 h-6 text-red-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Clear All Upcoming Slots</h3>
                <p className="text-sm text-gray-500">This action cannot be undone</p>
              </div>
            </div>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete all upcoming available slots? Booked slots will not be affected.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setConfirmClearAll(false)}
                className="flex-1 px-4 py-3 text-gray-700 font-medium border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleClearAllUpcoming}
                className="flex-1 px-4 py-3 bg-red-600 text-white font-semibold rounded-xl hover:bg-red-700 transition-colors"
              >
                Clear All
              </button>
            </div>
          </div>
        </>
      )}

      {showAddSlotForDay && selectedDay !== null && (
        <>
          <div
            className="fixed inset-0 bg-black/30  z-40"
            onClick={() => setShowAddSlotForDay(false)}
            onKeyDown={(e) => { if (e.key === 'Escape') setShowAddSlotForDay(false); }}
          />
          <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-white rounded-2xl shadow-2xl z-50 w-full max-w-md p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-900">Add Time Slot</h3>
              <button
                onClick={() => setShowAddSlotForDay(false)}
                className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mb-6">
              <p className="text-sm text-gray-600 mb-4">
                {new Date(currentDate.getFullYear(), currentDate.getMonth(), selectedDay).toLocaleDateString('en-AU', {
                  weekday: 'long',
                  day: 'numeric',
                  month: 'long',
                  year: 'numeric',
                })}
              </p>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Start Time</label>
                  <input
                    type="time"
                    step="300"
                    value={newSlotStartTime}
                    onChange={(e) => setNewSlotStartTime(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">End Time</label>
                  <input
                    type="time"
                    step="300"
                    value={newSlotEndTime}
                    onChange={(e) => setNewSlotEndTime(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                </div>
              </div>
              <p className="text-xs text-gray-400 mt-2">Select times in 5-minute intervals</p>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setShowAddSlotForDay(false)}
                className="flex-1 px-4 py-3 text-gray-700 font-medium border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleAddSlotForDay}
                disabled={newSlotStartTime >= newSlotEndTime || addingSlot}
                className="flex-1 px-4 py-3 bg-primary-600 text-white font-semibold rounded-xl hover:bg-primary-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {addingSlot ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Adding...
                  </>
                ) : (
                  'Add Slot'
                )}
              </button>
            </div>
          </div>
        </>
      )}

      {selectedConversation && (
        <ConversationSettingsModal
          isOpen={showConversationSettings}
          onClose={() => {
            setShowConversationSettings(false);
            setSelectedConversation(null);
          }}
          conversationId={selectedConversation.id}
          currentUserId={user?.id || ''}
          isAdmin={selectedConversation.myParticipation?.is_admin || false}
          onConversationUpdated={() => {
            fetchConversations();
            setShowConversationSettings(false);
            setSelectedConversation(null);
          }}
        />
      )}

      {selectedJob && (
        <JobManagementModal
          isOpen={showJobManagement}
          onClose={() => {
            setShowJobManagement(false);
            setSelectedJob(null);
          }}
          jobId={selectedJob}
          onJobUpdated={() => {
            fetchJobs();
            setShowJobManagement(false);
            setSelectedJob(null);
          }}
          isLicenseExpired={isLicenseExpired}
        />
      )}

{showDeleteConfirm && (
        <>
          <div
            className="fixed inset-0 bg-black/50  z-50"
            onClick={() => !deleting && setShowDeleteConfirm(false)}
            onKeyDown={(e) => { if (e.key === 'Escape' && !deleting) setShowDeleteConfirm(false); }}
          />
          <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-white rounded-2xl shadow-2xl z-50 w-full max-w-md p-6">
            <div className="flex items-center justify-center mb-4">
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                <Trash2 className="w-6 h-6 text-red-600" />
              </div>
            </div>
            <h3 className="text-xl font-bold text-gray-900 text-center mb-2">Delete Job</h3>
            <p className="text-gray-600 text-center mb-6">
              Are you sure you want to delete this job? This action cannot be undone.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                disabled={deleting}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-100 transition-colors disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteJob}
                disabled={deleting}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50"
              >
                {deleting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Deleting...
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    Delete
                  </>
                )}
              </button>
            </div>
          </div>
        </>
      )}

      {toast.show && (
        <div className={`fixed bottom-4 right-4 ${toast.isError ? 'bg-red-600' : 'bg-green-600'} text-white px-6 py-3 rounded-xl shadow-lg flex items-center gap-3 z-50 animate-slide-up`}>
          <div className={`w-2 h-2 ${toast.isError ? 'bg-red-300' : 'bg-green-300'} rounded-full animate-pulse`} />
          <span className="font-medium">{toast.message}</span>
        </div>
      )}

      <SubscriptionModal
        isOpen={showSubscriptionModal}
        onClose={() => setShowSubscriptionModal(false)}
      />

      <style>{`
        @keyframes slide-up {
          from {
            transform: translateY(100px);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }
        .animate-slide-up {
          animation: slide-up 0.3s ease-out;
        }
      `}</style>
    </DashboardLayout>
  );
}
