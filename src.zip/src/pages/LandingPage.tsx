import Navbar from '../components/Navbar';
import HeroSection from '../components/HeroSection';
import HowItWorksClientsSection from '../components/HowItWorksClientsSection';
import CategoriesSection from '../components/CategoriesSection';
import FeaturesSection from '../components/FeaturesSection';
import ForTradiesSection from '../components/ForTradiesSection';
import HowItWorksSection from '../components/HowItWorksSection';
import Footer from '../components/Footer';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white font-sans antialiased">
      <Navbar />
      <main>
        <HeroSection />
        <HowItWorksClientsSection />
        <CategoriesSection />
        <FeaturesSection />
        <ForTradiesSection />
        <HowItWorksSection />
      </main>
      <Footer />
    </div>
  );
}
