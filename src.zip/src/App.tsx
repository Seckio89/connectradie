import { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { replayOnReconnect } from './lib/serviceWorker';
import LandingPage from './pages/LandingPage';
import Login from './pages/Login';
import Register from './pages/Register';
import Onboarding from './pages/Onboarding';
import Dashboard from './pages/Dashboard';
import Search from './pages/Search';
import MyTrades from './pages/MyTrades';
import Verification from './pages/Verification';
import Settings from './pages/Settings';
import Jobs from './pages/Jobs';
import Messages from './pages/Messages';
import Explore from './pages/Explore';
import Projects from './pages/Projects';
import PostLead from './pages/PostLead';
import Leads from './pages/Leads';
import AdminVerifications from './pages/AdminVerifications';
import Team from './pages/Team';
import SiteCalendar from './pages/SiteCalendar';
import TradeCareers from './pages/TradeCareers';
import Schedule from './pages/Schedule';
import WorkHub from './pages/WorkHub';
import PerformanceInsights from './pages/PerformanceInsights';
import PublicTradieProfile from './pages/PublicTradieProfile';
import MyProfile from './pages/MyProfile';
import NotFound from './pages/NotFound';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import Contact from './pages/Contact';
import { Loader2 } from 'lucide-react';

function ProtectedRoute({ children, requireAdmin, requireTradie, requireOnboarding = true }: { children: React.ReactNode; requireAdmin?: boolean; requireTradie?: boolean; requireOnboarding?: boolean }) {
  const { user, profile, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-primary-600 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" />;
  }

  if (requireOnboarding && profile && !profile.onboarding_completed) {
    return <Navigate to="/onboarding" />;
  }

  if (requireAdmin && profile?.role !== 'admin') {
    return <Navigate to="/dashboard" />;
  }

  if (requireTradie && profile?.role !== 'tradie') {
    return <Navigate to="/dashboard" />;
  }

  return <>{children}</>;
}

function PublicRoute({ children }: { children: React.ReactNode }) {
  const { user, profile, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-primary-600 animate-spin" />
      </div>
    );
  }

  if (user && profile?.onboarding_completed) {
    return <Navigate to="/dashboard" />;
  }

  return <>{children}</>;
}

function AppRoutes() {
  useEffect(() => {
    replayOnReconnect();
    window.addEventListener('online', replayOnReconnect);
    return () => window.removeEventListener('online', replayOnReconnect);
  }, []);

  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />
      <Route
        path="/login"
        element={
          <PublicRoute>
            <Login />
          </PublicRoute>
        }
      />
      <Route
        path="/register"
        element={
          <PublicRoute>
            <Register />
          </PublicRoute>
        }
      />
      <Route
        path="/onboarding"
        element={
          <ProtectedRoute requireOnboarding={false}>
            <Onboarding />
          </ProtectedRoute>
        }
      />
      <Route
        path="/dashboard"
        element={
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        }
      />
      <Route path="/search" element={<Search />} />
      <Route path="/tradie/:id" element={<PublicTradieProfile />} />
      <Route path="/explore" element={<Explore />} />
      <Route path="/terms" element={<Terms />} />
      <Route path="/privacy" element={<Privacy />} />
      <Route path="/contact" element={<Contact />} />
      <Route
        path="/my-trades"
        element={
          <ProtectedRoute>
            <MyTrades />
          </ProtectedRoute>
        }
      />
      <Route
        path="/jobs"
        element={
          <ProtectedRoute>
            <Jobs />
          </ProtectedRoute>
        }
      />
      <Route
        path="/projects"
        element={
          <ProtectedRoute>
            <Projects />
          </ProtectedRoute>
        }
      />
      <Route
        path="/post-lead"
        element={
          <ProtectedRoute>
            <PostLead />
          </ProtectedRoute>
        }
      />
      <Route
        path="/leads"
        element={
          <ProtectedRoute>
            <Leads />
          </ProtectedRoute>
        }
      />
      <Route
        path="/messages"
        element={
          <ProtectedRoute>
            <Messages />
          </ProtectedRoute>
        }
      />
      <Route
        path="/settings"
        element={
          <ProtectedRoute>
            <Settings />
          </ProtectedRoute>
        }
      />
      <Route
        path="/admin/verifications"
        element={
          <ProtectedRoute requireAdmin>
            <AdminVerifications />
          </ProtectedRoute>
        }
      />
      <Route
        path="/my-profile"
        element={
          <ProtectedRoute requireTradie>
            <MyProfile />
          </ProtectedRoute>
        }
      />
      <Route
        path="/schedule"
        element={
          <ProtectedRoute requireTradie>
            <Schedule />
          </ProtectedRoute>
        }
      />
      <Route
        path="/work"
        element={
          <ProtectedRoute requireTradie>
            <WorkHub />
          </ProtectedRoute>
        }
      />
      <Route
        path="/performance"
        element={
          <ProtectedRoute requireTradie>
            <PerformanceInsights />
          </ProtectedRoute>
        }
      />
      <Route
        path="/team"
        element={
          <ProtectedRoute requireTradie>
            <Team />
          </ProtectedRoute>
        }
      />
      <Route
        path="/trade-careers"
        element={
          <ProtectedRoute requireTradie>
            <TradeCareers />
          </ProtectedRoute>
        }
      />
      <Route
        path="/site-calendar"
        element={
          <ProtectedRoute requireTradie>
            <SiteCalendar />
          </ProtectedRoute>
        }
      />
      <Route path="/verification" element={<Navigate to="/settings" replace />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default function App() {
  return (
    <Router>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </Router>
  );
}
